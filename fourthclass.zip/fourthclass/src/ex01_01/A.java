package ex01_01;

//A클래스는 public 클래스이기 때문에 다른 패키지에서 사용가능하다.
public class A
{
    public int m = 3;
    public int n = 4;
    public void print()
    {
        System.out.println("임포트");
    }


}
